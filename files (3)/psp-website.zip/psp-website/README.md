# Perfect Solution Point Reading Library
### Sri Karanpur, Rajasthan — Official Website

---

## 📁 File Structure

```
/
├── index.html        → Homepage
├── about.html        → About Us page
├── membership.html   → Membership Plans & Pricing
├── contact.html      → Contact page
├── style.css         → Main stylesheet
├── script.js         → Animations & interactivity
└── images/           → Upload your images here (see below)
```

---

## 🖼️ Images to Upload

Create an `images/` folder and add these files:

| Filename | Used On |
|----------|---------|
| `psp-reading-library-logo.png` | Favicon (all pages) |
| `library in Sri Karanpur.jpg` | Homepage gallery + About page |
| `AC reading room in Sri Karanpur.jpg` | Homepage gallery |
| `study hall with wifi Sri Karanpur.jpg` | Homepage gallery |
| `library for competitive exams Sri Karanpur.jpg` | Homepage gallery |
| `Owner - Amar Kamboj.jpg` | About page — owner section |

> ⚠️ Image filenames are case-sensitive. Use exact names shown above.

---

## 🚀 Deploy on Render (Static Site)

1. Push this repo to GitHub
2. Go to [render.com](https://render.com) → New → Static Site
3. Connect your GitHub repo
4. Settings:
   - **Build Command:** *(leave empty)*
   - **Publish Directory:** `.` (root)
5. Click **Deploy** — done!

---

## 🌐 Business Details

- **Name:** Perfect Solution Point Reading Library
- **Location:** Devta Colony, Ward 24, Near Govt Hospital, Sri Karanpur, Rajasthan
- **Hours:** 7:00 AM – 10:00 PM, Open Daily
- **Established:** 5 January 2020
- **Owner:** Amar Kamboj

## 💰 Pricing Plans

| Plan | Price | Timings |
|------|-------|---------|
| Morning Shift | ₹400/month | 7:00 AM – 2:30 PM |
| Evening Shift | ₹400/month | 2:30 PM – 10:00 PM |
| Full Day | ₹700/month | 7:00 AM – 10:00 PM |
